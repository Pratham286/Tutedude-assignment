import { MAP_WIDTH, MAP_HEIGHT } from "../utils/constants.js";

const users = new Map();

export const setupSocket = (io) => {
    io.on("connection", (socket) => {
        console.log("User connected:", socket.id);

        socket.on("user:join", ({ username }) => {
            const user = {
                id: socket.id,
                username,
                x: Math.floor(Math.random() * (MAP_WIDTH - 200)) + 100,
                y: Math.floor(Math.random() * (MAP_HEIGHT - 200)) + 100,
            };

            users.set(socket.id, user);

            // Send this user their own data + all existing users
            socket.emit("user:joined", {
                user,
                users: Array.from(users.values()),
            });

            // Tell everyone else about the new user
            socket.broadcast.emit("user:new", user);
        });

        socket.on("user:move", ({ x, y }) => {
            const user = users.get(socket.id);
            if (!user) return;

            user.x = x;
            user.y = y;

            // Send updated position to everyone except this user
            socket.broadcast.emit("user:moved", {
                id: socket.id,
                x,
                y,
            });
        });

        socket.on("disconnect", () => {
            console.log("User disconnected:", socket.id);
            users.delete(socket.id);
            io.emit("user:left", socket.id);
        });
    });
};